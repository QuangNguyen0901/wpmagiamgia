<?php if( couponis_get_option( 'google_ads_header' ) == 'yes' ): ?>
<div class="couponis-avts">
	<div class="container">
			<?php echo couponis_get_option( 'google_ads' ) ?>
	</div>
</div>
<?php endif; ?>