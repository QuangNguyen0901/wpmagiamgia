<div class="white-block">
	<div class="white-block-content">
		<?php echo apply_filters( 'the_content', $atts['content'] ) ?>
	</div>
</div>